package com.ahmed.mohammed

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ahmed.mohammed.ui.theme.MyContactsTheme
import kotlinx.coroutines.launch

class MohammedActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyContactsTheme {
                ContactScreen()
            }
        }
    }

    @Composable
    fun ContactScreen(contactViewModel: ContactViewModel = viewModel()) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var isFriend by remember { mutableStateOf(false) }
        var isFamily by remember { mutableStateOf(false) }
        var isWork by remember { mutableStateOf(false) }

        val snackbarHostState = remember { SnackbarHostState() }
        val scope = rememberCoroutineScope()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Back Arrow Icon for navigation to the first screen
            IconButton(onClick = {
                // Navigate back to the first screen (AhmedActivity)
                val intent = Intent(this@MohammedActivity, AhmedActivity::class.java)
                startActivity(intent)
                finish() // Optional: finish the current activity
            }) {
                Icon(
                    imageVector = Icons.Filled.ArrowBack,
                    contentDescription = "Back",
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Heading
            Text(
                text = "Create New Contact",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp),
                color = MaterialTheme.colorScheme.primary
            )

            // Name Input
            TextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Name", fontSize = 18.sp) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(fontSize = 16.sp)
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Phone Input
            TextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number", fontSize = 18.sp) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(fontSize = 16.sp)
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Email Input
            TextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email", fontSize = 18.sp) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(fontSize = 16.sp)
            )
            Spacer(modifier = Modifier.height(24.dp))

            // Contact Type Label
            Text(
                text = "Select Contact Type:",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )

            // Checkboxes for Contact Type
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(checked = isFriend, onCheckedChange = { isFriend = it })
                Text(text = "Friend", fontSize = 16.sp)
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(checked = isFamily, onCheckedChange = { isFamily = it })
                Text(text = "Family", fontSize = 16.sp)
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(checked = isWork, onCheckedChange = { isWork = it })
                Text(text = "Work", fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Add Contact Button
            Button(
                onClick = {
                    val contactType = getContactType(isFriend, isFamily, isWork)
                    contactViewModel.addContact(Contact(name, phone, email, contactType))

                    // Clear input fields after adding contact
                    name = ""
                    phone = ""
                    email = ""
                    isFriend = false
                    isFamily = false
                    isWork = false

                    // Show Snackbar notification
                    scope.launch {
                        snackbarHostState.showSnackbar("Contact added: $name")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text("Add Contact", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Snackbar Host
            SnackbarHost(hostState = snackbarHostState)

            // Display contact list using LazyColumn
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(contactViewModel.contacts) { contact ->
                    ContactCard(contact)
                }
            }
        }
    }

    @Composable
    fun ContactCard(contact: Contact) {
        // Each contact displayed in a Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 16.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Name: ${contact.name}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = "Phone: ${contact.phone}",
                    fontSize = 16.sp
                )
                Text(
                    text = "Email: ${contact.email}",
                    fontSize = 16.sp
                )
                Text(
                    text = "Type: ${contact.type}",
                    fontSize = 16.sp
                )
            }
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun ContactScreenPreview() {
        MyContactsTheme {
            ContactScreen()
        }
    }

    private fun getContactType(isFriend: Boolean, isFamily: Boolean, isWork: Boolean): String {
        return when {
            isFriend -> "Friend"
            isFamily -> "Family"
            isWork -> "Work"
            else -> "Unknown"
        }
    }
}
