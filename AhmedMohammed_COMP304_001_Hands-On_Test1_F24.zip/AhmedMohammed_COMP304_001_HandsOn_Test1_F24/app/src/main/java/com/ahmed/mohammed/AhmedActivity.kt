package com.ahmed.mohammed

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ahmed.mohammed.ui.theme.MyContactsTheme

class AhmedActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyContactsTheme {
                MainScreen()
            }
        }
    }

    @Composable
    fun MainScreen() {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Title or App Name
            Text(
                text = "My Contacts",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp),
                color = Color(0xFF333333)
            )

            // App Logo
            Image(
                painter = painterResource(id = R.drawable.ic_contacts),
                contentDescription = "App Logo",
                modifier = Modifier
                    .size(120.dp) 
                    .padding(16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp)) // More space between the logo and the button

            // Button for navigating to the Contacts Screen
            Button(
                onClick = {
                    startActivity(Intent(this@AhmedActivity, MohammedActivity::class.java))
                },
                modifier = Modifier
                    .width(200.dp)
                    .height(60.dp),
                shape = MaterialTheme.shapes.medium,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6200EE)) // Material 3 Button color
            ) {
                Text(
                    text = "Go to Contacts",
                    fontSize = 18.sp,
                    color = Color.White,
                    textAlign = TextAlign.Center //center the text in the button
                )
            }
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun MainScreenPreview() {
        MyContactsTheme {
            MainScreen()
        }
    }
}
