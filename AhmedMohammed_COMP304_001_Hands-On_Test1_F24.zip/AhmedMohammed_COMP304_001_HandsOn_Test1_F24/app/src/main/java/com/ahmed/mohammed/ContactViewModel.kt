package com.ahmed.mohammed

import androidx.lifecycle.ViewModel
import androidx.compose.runtime.mutableStateListOf

data class Contact(val name: String, val phone: String, val email: String, val type: String)

class ContactViewModel : ViewModel() {
    var contacts = mutableStateListOf<Contact>()
        private set

    fun addContact(contact: Contact) {
        contacts.add(contact)
    }
}
